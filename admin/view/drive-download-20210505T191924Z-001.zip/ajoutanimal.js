function Envoyer()
{
  var  nom = document.getElementById('nom').value;
  var missNom=document.getElementById('missnom');
 



  if(nom.charAt(0) !== nom.charAt(0).toUpperCase())
  {
       alert("Nom doit commancer par une majuscule");
  }
  
  
  
  


}